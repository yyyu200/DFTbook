#!/bin/bash

set -e
ncore=2 
qedir="$HOME/download/qe-6.6/bin"
PWBIN="$qedir/pw.x"
PHBIN="$qedir/ph.x"
MPI_OPTION="mpirun -np $ncore"

#$MPI_OPTION $PWBIN < vc.inp > vc.out 2>err

#if  true  ; then
$MPI_OPTION $PWBIN < scf0.inp > scf0.out 2>err
$MPI_OPTION $PWBIN < scf.inp > scf.out 2>err
$MPI_OPTION $PHBIN < ph.inp > ph.out 2>err 
$qedir/q2r.x < q2r.inp > q2r.out 2>err
$qedir/matdyn.x < matdyn1.inp > matdyn1.out 2>err
$qedir/matdyn.x < matdyn2.inp > matdyn2.out 2>err
$qedir/lambda.x < lambda.inp > lambda.out 2>err
#fi
