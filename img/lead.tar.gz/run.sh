#!/bin/bash
ncore=16

PWBIN="$HOME/local/q-e-qe-6.5/bin/pw.x"
PHBIN="$HOME/local/q-e-qe-6.5/bin/ph.x"
MPI_OPTION="mpirun -np $ncore"

#$MPI_OPTION $PWBIN < vc.inp > vc.out 2>err

if  true  ; then
$MPI_OPTION $PWBIN < scf0.inp > scf0.out 2>err
$MPI_OPTION $PWBIN < scf.inp > scf.out 2>err
$MPI_OPTION $PHBIN < ph.inp > ph.out 2>err 
$HOME/local/q-e-qe-6.5/bin/q2r.x < q2r.inp > q2r.out 2>err
$HOME/local/q-e-qe-6.5/bin/matdyn.x < matdyn1.inp > matdyn1.out 2>err
$HOME/local/q-e-qe-6.5/bin/matdyn.x < matdyn2.inp > matdyn2.out 2>err
$HOME/local/q-e-qe-6.5/bin/lambda.x < lambda.inp > lambda.out 2>err
fi
