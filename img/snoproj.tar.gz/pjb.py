#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np

ymin=-25
ymax=10
dline=30 # vertical line intervals
lw=0.5 # line width
nband=26

feig=open('bd.dat')
l=feig.readline()
nbnd=int(l.split(',')[0].split('=')[1])
nks=int(l.split(',')[1].split('=')[1].split('/')[0])

eig=np.zeros((nks,nbnd),dtype=float)
for i in range(nks):
    l=feig.readline()
    count=0
    for j in range(nbnd//10+1):
        l=feig.readline()
        for k in range(len(l.split())):
            eig[i][count]=l.split()[k]
            count=count+1
            
feig.close()

import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt

F=plt.gcf()
F.set_size_inches([5,5])
p1=plt.subplot(1, 1, 1)

eig_vbm=max(eig[:,nband-1])
for i in range(nbnd):
    line1=plt.plot(np.arange(0,nks), eig[:,i]-eig_vbm,color='grey',linewidth=lw ) 

vline=dline
while vline<nks-1:
    plt.axvline(x=vline, ymin=ymin, ymax=ymax,linewidth=lw,color='black')
    vline=vline+dline


elem=['Sn','O']
ielem=np.array([2,4],dtype=np.int32) # number of atoms for each element
orb=[['s','p','d'],['s','p']]  # projectors for each element

N=len(elem)
iorb=np.zeros([N,],dtype=np.int32)  # number of projectors for each element
for i in range(N):
    iorb[i]=len(orb[i])

lorb=np.zeros([N,],dtype=np.int32) # number of local orbital for each element
for i in range(N):
    for j in orb[i]:
        if j is 's':
            lorb[i]+=1
        elif j is 'p':
            lorb[i]+=3
        elif j is 'd':
            lorb[i]+=5
        elif j is 'f':
            lorb[i]+=7
        else:
            print("unexpect: ",j)
            assert False

nlorb=np.dot(ielem,lorb)

pjsum=np.zeros([nlorb, nks, nbnd], dtype=np.float32)

filproj=open('sno.projwfc_up')
nline_io_header=14

for i in range(nline_io_header):
    filproj.readline()

for i in range(nlorb):
    filproj.readline()
    for j in range(nks):
        for k in range(nbnd):
            pjsum[i,j,k]=float(filproj.readline().split()[2])

nplotline=np.sum(iorb) 
#grep '[a-zA-Z]' sno.projwfc_up |grep 2P|awk '{printf( $1-1",")}'
oo=[[0,9],
[1,2,3,10,11,12],
[4,5,6,7,8,13,14,15,16,17],
[18,22,26,30],
[19,20,21,23,24,25,27,28,29,31,32,33]]

s_of_o=np.zeros([nks,],dtype=np.float32)
color=['r','g','orange','cyan','blue']
label=['Sn s','Sn p','Sn d','O s','O p']

scale=10.0
st=[]
for i in range(len(oo)):
    for k in range(nbnd):
        s_of_o=np.zeros([nks,],dtype=np.float32)
        for j in oo[i]:
            s_of_o[:]+=pjsum[j,:,k]
        if k==0:
            st.append(plt.scatter(np.arange(0,nks), eig[:,k]-eig_vbm, s=scale*s_of_o, c=color[i], alpha=0.4, label=label[i]))
        else:
            st.append(plt.scatter(np.arange(0,nks), eig[:,k]-eig_vbm, s=scale*s_of_o, c=color[i], alpha=0.4))

plt.xlim([0,nks-1]) # 201 points
plt.ylim([ymin,ymax])
plt.ylabel(r' E (eV) ',fontsize=16)
plt.xticks((0,30,60), ('M', r'${\Gamma}$', 'Z') )


plt.subplots_adjust(left=0.15, right=0.8, top=0.95, bottom=0.1)
p1.legend(scatterpoints =1, numpoints=1,markerscale=2.0, bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0.)

plt.savefig('pjband.png',dpi=500)


