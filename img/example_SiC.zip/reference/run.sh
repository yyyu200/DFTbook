#!/bin/bash

pw.x < vc.inp> vc.out  2>>stderr

pw.x < nscf_b.inp> nscf_b.out  2>>stderr

bands.x < bands.inp > bands.out 2>>stderr

python3 qebandplot.py
